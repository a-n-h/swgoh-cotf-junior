'''Pulls a guild's list of ally codes from swogh.gg, loads them into .csv.

Places a GET call to http://swgoh.gg/api/guild/{guild_id}.

Organizes the data into a Data Frame using Pandas.
Exports the data into .csv, using Pipe (|) as delimiter.
Location of the export is in the same directory as the script.
Offers some additional insights into the guild dictionary as well, for the more
agile inquiries.

Made freely available under GNU GPL 3.0 (see license.txt)
    
    Copyright (C) 2020  David Millikin

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

Please note that this module includes NO WARRANTIES WHATSOEVER FOR ANY PURPOSE.
Use at your own risk.  Modify at your discretion.

This module may require other Python modules to work.

This module assumes the existence and operation of the website SWGOH.GG.

This software requires the user to know the guild's ID for either function in
this module to work.  Check the website https://swgoh.gg to get your guild's ID.
This can be found by visiting your guild's .gg page, and identifying the
5-digit code in the address bar, as: https://swgoh.gg/g/<guild-id>/<guild-name>.
'''

import pandas as pd
import requests
from datetime import date

player_guild = input("Enter your guild's 5-digit swgoh.gg ID:\n")
try:
        url = "http://swgoh.gg/api/"
        url_guild = url+"guild/"+str(player_guild)
        guild = requests.get(url_guild)
        guild = guild.json()  # Converts the request into dictionary data type.

        # The guild dictionary contains two elements: Data and Players.
        guild_players = guild["players"]  # type = 'list'
        guild_data = guild["data"]  # type = 'dict'

        # Guild Basic Details (not used in the output):
        guild_gp = guild_data["galactic_power"]
        avg_gp = guild_data["galactic_power"] / guild_data["member_count"]
        guild_member_count = guild_data["member_count"]

        # Compile Guild Ally Codes into a List:
        guild_ally_codes = list()
        for i in range(0,guild_data["profile_count"]):
                guild_ally_codes.append(guild_players[i]["data"]["ally_code"])

        # Export the data into .csv:
        today = str(date.today())
        filename = str(player_guild)+'_'+today+'.csv'
        allycode_df = pd.DataFrame(guild_ally_codes, columns = ['Ally Code'])
        allycode_df.to_csv(filename, sep='|')

except Exception as bad_code:
        print(bad_code)
        input("The code you entered must be 5 digits and be a guild ID from "
              "swgoh.gg. You may try again by re-running the script. Press "
              "'Enter' to close the app.")
