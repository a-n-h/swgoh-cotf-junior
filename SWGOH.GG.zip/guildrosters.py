'''Create a list of guild players and all their toons.

    Copyright (C) 2020  David Millikin

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

Please note that this module includes NO WARRANTIES WHATSOEVER FOR ANY PURPOSE.
Use at your own risk.  Modify at your discretion.

This module may require other Python modules to work.

This module assumes the existence and operation of the website SWGOH.GG.

This software requires the user to know the guild's ID for either function in
this module to work.  Check the website https://swgoh.gg to get your guild's ID.
This can be found by visiting your guild's .gg page, and identifying the
5-digit code in the address bar, as: https://swgoh.gg/g/<guild-id>/<guild-name>.
This is the only argument used in either function.  The default guild_id is the
original author's guild.
'''

import pandas as pd
import requests
import player
import guild_members
from datetime import date

def generatePlayerRosters(guild_id=24243):
    '''Returns a List and a Data Frame version of a guild's roster.

    This may take a minute or two to process, as the function pulls from
    swgoh.gg, and loops through all the toons of all the players in a guild.

    

    '''

    gm, gm_df = guild_members.createPlayerList(guild_id)

    member_name = list()
    member_allycode = list()
    member_toons = list()
    toon_star_level = list()
    toon_gp = list()
    roster = dict()

    for i in range(0, len(gm['allycode'])):
        
        print('Now loading ', gm['name'][i], '...', sep='')
        player_toons, player_toons_df = player.playerToonGP(gm['allycode'][i])

        for j in range(0, len(player_toons['toon name'])):
            member_name.append(gm['name'][i])
            member_allycode.append(gm['allycode'][i])
            member_toons.append(player_toons['toon name'][j])
            toon_star_level.append(player_toons['star level'][j])
            toon_gp.append(player_toons['power'][j])

    roster['Member'] = member_name
    roster['AllyCode'] = member_allycode
    roster['ToonName'] = member_toons
    roster['StarLevel'] = toon_star_level
    roster['GP'] = toon_gp

    roster_df = pd.DataFrame(roster)
    print('Done!')

    return roster, roster_df


def exportMyGuild(guild_id=24243):
    '''Export the entire roster with certain attributes of each toons into .csv.

    '''

    member_units = dict()

    guild_accounts, guild_accounts_df = guild_members.createPlayerList(guild_id)  #24243
    today = str(date.today())
    filename = str(guild_id)+today+'.csv'
    
    
    for i in range (0, len(guild_accounts['name'])):
        fraction = str(i+1) + '/' + str(len(guild_accounts['name']))
        print('Processing ', guild_accounts['name'][i], ' (', fraction, ')...', sep='')
        playerunits, playerdata = player.loadPlayer(guild_accounts['allycode'][i])  # 468977136
        member_units = player.myUnits(playerdata, playerunits)
        if i == 0:
            unit_df = pd.DataFrame(member_units).transpose()
        else:
            unit_df2 = pd.DataFrame(member_units).transpose()
            unit_df = unit_df.append(unit_df2)

    unit_df.to_csv(filename, sep='|')

    return member_units, unit_df


def main():

    guild_id = input('Please enter the guild id:\n')
    roster, roster_df = generatePlayerRosters(guild_id)

    roster_count = len(roster['Ally Code'])
    print('Guild members in this guild have ', roster_count, 'active toons.')
    input('Press enter to close the program.')
    
    
if __name__ == 'main':
    main()
    
